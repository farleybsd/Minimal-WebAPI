﻿namespace RangoAgil.API.Models;
public class RangoDTO
{
    public int Id { get; set; }
    public required string Nome { get; set; }
}
