﻿namespace RangoAgil.API.Models;
public class RangoParaAtualizacaoDTO
{
    public required string Nome { get; set; }
}
